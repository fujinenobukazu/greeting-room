-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- ホスト: localhost:3306
-- 生成日時: 2020 年 11 月 13 日 20:18
-- サーバのバージョン： 5.7.26
-- PHP のバージョン: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `creative_php`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `assignment`
--

CREATE TABLE `assignment` (
  `assignment_id` varchar(5) NOT NULL COMMENT '配属先ID',
  `assignment_name` varchar(255) NOT NULL COMMENT '配属先名',
  `department_id` varchar(5) NOT NULL COMMENT '部署ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='配属先テーブル';

--
-- テーブルのデータのダンプ `assignment`
--

INSERT INTO `assignment` (`assignment_id`, `assignment_name`, `department_id`) VALUES
('101', 'Aチーム', 'A001'),
('102', 'Bチーム', 'A001'),
('201', '管理課', 'E001'),
('303', 'Cチーム', 'C001');

-- --------------------------------------------------------

--
-- テーブルの構造 `attendance`
--

CREATE TABLE `attendance` (
  `day` date NOT NULL COMMENT '日付',
  `user_id` int(10) NOT NULL,
  `in_time` time NOT NULL COMMENT '出勤',
  `out_time` time DEFAULT NULL COMMENT '退勤',
  `break_time` int(3) DEFAULT NULL COMMENT '休憩'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `attendance`
--

INSERT INTO `attendance` (`day`, `user_id`, `in_time`, `out_time`, `break_time`) VALUES
('2020-09-24', 1, '09:00:00', '18:00:00', 60),
('2020-10-01', 1, '09:00:00', '19:00:00', 60),
('2020-10-01', 2, '10:00:00', '19:00:00', 60),
('2020-10-01', 3, '14:16:00', '22:16:00', 70),
('2020-10-02', 1, '09:00:00', '18:00:00', 60),
('2020-10-03', 1, '09:00:00', '18:00:00', 80),
('2020-10-04', 1, '09:00:00', '19:15:00', 80),
('2020-10-05', 4, '00:00:00', '00:00:00', 10),
('2020-10-06', 3, '13:16:00', '18:17:00', 60),
('2020-10-08', 2, '10:13:00', '19:13:00', 60),
('2020-10-12', 4, '09:15:00', '16:15:00', 0),
('2020-10-13', 1, '09:12:00', '16:12:00', 60),
('2020-10-13', 2, '09:15:35', '23:15:50', 80),
('2020-10-29', 2, '13:14:06', '13:14:09', 70),
('2020-10-30', 1, '17:01:29', '17:01:53', 60),
('2020-11-01', 7, '07:19:00', '18:19:00', 60),
('2020-11-02', 7, '09:19:00', '18:20:00', 60),
('2020-11-12', 1, '14:09:52', '14:09:55', 60);

-- --------------------------------------------------------

--
-- テーブルの構造 `department`
--

CREATE TABLE `department` (
  `department_id` varchar(5) NOT NULL COMMENT '部署ID',
  `department_name` varchar(255) NOT NULL COMMENT '部署名'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='部署テーブル';

--
-- テーブルのデータのダンプ `department`
--

INSERT INTO `department` (`department_id`, `department_name`) VALUES
('A001', '営業部'),
('B005', '事業部'),
('C001', '広報部'),
('E001', '管理部');

-- --------------------------------------------------------

--
-- テーブルの構造 `role`
--

CREATE TABLE `role` (
  `role_id` int(1) NOT NULL COMMENT '管理者ID',
  `role_name` varchar(255) NOT NULL COMMENT '権限レベル'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `role`
--

INSERT INTO `role` (`role_id`, `role_name`) VALUES
(0, '一般'),
(1, '監査'),
(2, '管理者');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `id` int(6) NOT NULL,
  `assignment_id` varchar(5) NOT NULL COMMENT '配属先ID',
  `status` int(1) NOT NULL COMMENT '0=入社前、1=勤続、2=退社',
  `password` varchar(255) NOT NULL COMMENT 'パスワード',
  `position` varchar(20) NOT NULL COMMENT '役職',
  `name` varchar(50) NOT NULL COMMENT '名前',
  `email` varchar(255) NOT NULL COMMENT 'メールアドレス',
  `tell` varchar(20) NOT NULL COMMENT '電話番号',
  `str_address` varchar(255) NOT NULL COMMENT '住所',
  `salary` int(10) NOT NULL COMMENT '給与',
  `role` int(1) NOT NULL COMMENT '管理者権限',
  `join_day` date NOT NULL COMMENT '入社年月日',
  `birthday` date NOT NULL COMMENT '生年月日',
  `user_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '作成日',
  `user_update` datetime DEFAULT NULL COMMENT '更新日'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `users`
--

INSERT INTO `users` (`id`, `assignment_id`, `status`, `password`, `position`, `name`, `email`, `tell`, `str_address`, `salary`, `role`, `join_day`, `birthday`, `user_create`, `user_update`) VALUES
(1, '102', 2, '$2y$10$/hgScCt2V1s8phC6DOHqvejXun4wclxiQ2JT0.z5Px8hJxdN8XTDa', '社長', '藤根　宣和', 'nobu@mail.com', '090-4026-2222', '神奈川県相模原市', 900, 2, '2000-01-01', '1991-03-08', '2020-10-30 04:50:43', '2020-10-29 15:37:00'),
(2, '101', 1, '$2y$10$JnPdTOKkYiwXLpw6yaLj2emPagJKGBub8zGm3Bp9Xs8Vg.ZyLGSq2', '秘書', '天野　花子', 'ama@mail.com', '080-1111-2222', '神奈川', 2000000, 1, '2010-01-01', '2000-01-01', '2020-11-01 13:14:42', '2020-11-01 22:14:42'),
(3, '201', 0, '$2y$10$7YqJY8YPnNPC099TxUc/m.OQJwBtus4A0ta0g39j1su2sWAgvLmU.', '一般', '黒川　太郎', 'kapi@mail.com', '042-111-3333', '上北沢a', 10, 0, '2020-01-01', '2017-02-01', '2020-10-29 06:54:20', '2020-10-29 15:54:20'),
(4, '101', 0, '$2y$10$jW5m6u4e0LfPsjcaLsYoiOjnmtKLMkajtju5iIPXzjU81T9A1YKXy', '秘書', '田中　太郎', 'tanaka@mail.com', '0120-333-333', 'アイルランド', 4000, 0, '2020-10-01', '1984-02-16', '2020-10-29 06:54:44', '2020-10-29 15:54:44'),
(5, '303', 1, '$2y$10$9GdZPhehe.i6/qfeDwDEe.KpaBUw2kVGbvPSweC1R5O0WzVU24x0a', '一般', '山田　次郎', 'nobu.volleyball@gmail.com', '00001111', '沖縄', 100000, 0, '2020-10-29', '1990-05-16', '2020-10-30 06:21:45', '2020-10-30 14:45:50'),
(6, '101', 1, '$2y$10$R7Uhqe4I7u5Ua1nPnSe1J.a.jRVIdDl/OwspJXww9B41HOxppYmWi', '一般', '栗山　翔太', 'densya@mail.com', '07000505050', '神奈川県', 240000, 0, '2016-05-01', '1994-11-10', '2020-11-01 13:12:52', '2020-11-01 22:12:52'),
(7, '101', 1, '$2y$10$4mOmUyKPWtAwNtsTVbe6AujAN1GJNhg/XmmmO4ES6tKQnxhiheScu', '一般', '和田　寿子', 'mogumogu@mail.com', '090000101010', '東京都', 230000, 0, '2002-05-01', '1995-09-10', '2020-11-01 13:16:37', NULL);

-- --------------------------------------------------------

--
-- テーブルの構造 `user_status`
--

CREATE TABLE `user_status` (
  `status_id` int(1) NOT NULL,
  `status_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `user_status`
--

INSERT INTO `user_status` (`status_id`, `status_name`) VALUES
(0, '入社前'),
(1, '勤続'),
(2, '退社');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`assignment_id`),
  ADD KEY `department_id` (`department_id`);

--
-- テーブルのインデックス `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`day`,`user_id`),
  ADD KEY `attendance_link` (`user_id`);

--
-- テーブルのインデックス `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- テーブルのインデックス `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignment_id` (`assignment_id`),
  ADD KEY `status` (`status`),
  ADD KEY `role_link` (`role`),
  ADD KEY `email` (`email`);

--
-- テーブルのインデックス `user_status`
--
ALTER TABLE `user_status`
  ADD PRIMARY KEY (`status_id`);

--
-- ダンプしたテーブルのAUTO_INCREMENT
--

--
-- テーブルのAUTO_INCREMENT `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int(1) NOT NULL AUTO_INCREMENT COMMENT '管理者ID', AUTO_INCREMENT=3;

--
-- テーブルのAUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- ダンプしたテーブルの制約
--

--
-- テーブルの制約 `assignment`
--
ALTER TABLE `assignment`
  ADD CONSTRAINT `assign_link` FOREIGN KEY (`department_id`) REFERENCES `department` (`department_id`);

--
-- テーブルの制約 `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_link` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- テーブルの制約 `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `role_link` FOREIGN KEY (`role`) REFERENCES `role` (`role_id`),
  ADD CONSTRAINT `status_link` FOREIGN KEY (`status`) REFERENCES `user_status` (`status_id`),
  ADD CONSTRAINT `users` FOREIGN KEY (`assignment_id`) REFERENCES `assignment` (`assignment_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
